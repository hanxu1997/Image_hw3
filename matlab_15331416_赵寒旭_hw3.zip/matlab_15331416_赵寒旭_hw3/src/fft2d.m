function output_img = fft2d( input_img,flag )
    [m,n] = size(input_img);
    % 0��չ��2��n�η�
    [M,N] = paddingSize(input_img);
    output_img = zeros(M,N);
    item = zeros(M,N);
    item(1:m,1:n) = input_img;
    input_img = item;
    % �ж������任
    if flag == 1
        input_img = conj(input_img);
    end

    for v=1:M
        % row operation
        row_item = input_img(v,:);
        dft_row = fft1d(row_item);
        output_img(v,:) = dft_row;
    end
    for u=1:N
        col_item = output_img(:,u);
        dft_col = fft1d(col_item);
        output_img(:,u) = dft_col;
    end
    if flag == 1
        output_img = output_img / (M*N);
        output_img = conj(output_img);
    end
end

